"""Storage adapters share inputs and output tuples, not implementation details."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from .data import FIELDS, iter_parts

NAMES = ["fastk", "sqlite", "duckdb", "parquet", "arrow"]


class FastK:
    def __init__(self, root, manifest, binary):
        from fastk_client import Client

        self.client = Client(root, binary=binary, timeout=300)
        self.manifest = manifest

    def append(self, part, table):
        if part["kind"] == "bars":
            self.client.write_kline_range(
                part["symbol"],
                "1m",
                table.to_pylist(),
                timeframe_ms=60000,
                price_scale=self.manifest["scale"],
                volume_scale=self.manifest["scale"],
            )
        else:
            self.client.write_scalar_range(
                part["symbol"],
                "1m",
                "feature",
                part["kind"],
                table.to_pylist(),
                timeframe_ms=60000,
            )

    def setup(self, source):
        for part, table in iter_parts(source, self.manifest):
            self.append(part, table)

    def query(self, q):
        if q["kind"].startswith("predicate-"):
            records = self.client.query_scalar_predicate(
                q["symbol"],
                "1m",
                "feature",
                q["feature"],
                q["start_ts"],
                q["end_ts"],
                predicate="eq" if "value" in q else "between",
                value=q.get("value"),
                min=q.get("min"),
                max=q.get("max"),
            )["matches"]
            return [(row["ts"], row["value"]) for row in records]
        if "feature" in q:
            records = self.client.read_scalar_range(
                q["symbol"], "1m", "feature", q["feature"], q["start_ts"], q["end_ts"]
            )["records"]
            return [(row["ts"], row["value"]) for row in records]
        if q["kind"] == "latest":
            records = self.client.read_kline_latest(q["symbol"], "1m", q["limit"])["records"]
        else:
            records = self.client.read_kline_range(q["symbol"], "1m", q["start_ts"], q["end_ts"])[
                "records"
            ]
        fields = ["ts", "close"] if q["kind"] == "projection" else FIELDS
        return [tuple(row[field] for field in fields) for row in records]

    def close(self):
        pass


class Sql:
    def __init__(self, root, manifest, binary=None, *, duck=False):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.duck = duck
        if duck:
            import duckdb

            self.connection = duckdb.connect(str(self.root / "data.duckdb"))
            self.connection.execute("SET threads=1")
        else:
            self.connection = sqlite3.connect(self.root / "data.sqlite")
            self.connection.executescript(
                "PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA cache_size=-65536;"
            )
        self.manifest = manifest

    def setup(self, source):
        tail = "" if self.duck else " WITHOUT ROWID"
        integer = "BIGINT" if self.duck else "INTEGER"
        self.connection.execute(
            f"CREATE TABLE bars(symbol TEXT NOT NULL,ts {integer} NOT NULL,open {integer} NOT NULL,high {integer} NOT NULL,low {integer} NOT NULL,close {integer} NOT NULL,volume {integer} NOT NULL,PRIMARY KEY(symbol,ts)){tail}"
        )
        self.connection.execute(
            f"CREATE TABLE features(symbol TEXT NOT NULL,name TEXT NOT NULL,ts {integer} NOT NULL,value {integer} NOT NULL,PRIMARY KEY(symbol,name,ts)){tail}"
        )
        if self.duck:
            self.connection.execute("BEGIN TRANSACTION")
        for part, table in iter_parts(source, self.manifest):
            self.append(part, table, commit=False)
        self.connection.commit()
        self.connection.execute("CREATE INDEX feature_value ON features(symbol,name,value,ts)")
        self.connection.commit()
        if self.duck:
            self.connection.execute("CHECKPOINT")
        else:
            self.connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")

    def append(self, part, table, commit=True):
        if self.duck:
            self.connection.register("incoming", table)
            if part["kind"] == "bars":
                self.connection.execute(
                    "INSERT INTO bars SELECT ?,ts,open,high,low,close,volume FROM incoming",
                    [part["symbol"]],
                )
            else:
                self.connection.execute(
                    "INSERT INTO features SELECT ?,?,ts,value FROM incoming",
                    [part["symbol"], part["kind"]],
                )
            self.connection.unregister("incoming")
        elif part["kind"] == "bars":
            self.connection.executemany(
                "INSERT INTO bars VALUES (?,?,?,?,?,?,?)",
                [(part["symbol"], *row.values()) for row in table.to_pylist()],
            )
        else:
            self.connection.executemany(
                "INSERT INTO features VALUES (?,?,?,?)",
                [(part["symbol"], part["kind"], *row.values()) for row in table.to_pylist()],
            )
        if commit:
            self.connection.commit()

    def query(self, q):
        feature = q.get("feature")
        columns = (
            "ts,value"
            if feature
            else ("ts,close" if q["kind"] == "projection" else ",".join(FIELDS))
        )
        sql = f"SELECT {columns} FROM {'features' if feature else 'bars'} WHERE symbol=? AND ts>=? AND ts<=?"
        params = [q["symbol"], q["start_ts"], q["end_ts"]]
        if feature:
            sql += " AND name=?"
            params.append(feature)
        if "value" in q:
            sql += " AND value=?"
            params.append(q["value"])
        if "min" in q:
            sql += " AND value>=? AND value<=?"
            params.extend([q["min"], q["max"]])
        sql += " ORDER BY ts " + ("DESC LIMIT ?" if q["kind"] == "latest" else "ASC")
        if q["kind"] == "latest":
            params.append(q["limit"])
        rows = self.connection.execute(sql, params).fetchall()
        return list(reversed(rows)) if q["kind"] == "latest" else rows

    def close(self):
        self.connection.close()


class Files:
    def __init__(self, root, manifest, binary=None, *, parquet=False):
        self.root = Path(root)
        self.parquet = parquet
        self.manifest = manifest
        self.maps = {}

    def path(self, part):
        return self.root / Path(part["path"]).with_suffix(".parquet" if self.parquet else ".arrow")

    def append(self, part, table):
        import pyarrow as pa

        path = self.path(part)
        path.parent.mkdir(parents=True, exist_ok=True)
        if self.parquet:
            import pyarrow.parquet as pq

            pq.write_table(
                table,
                path,
                compression="zstd",
                row_group_size=8192,
                write_statistics=True,
            )
        else:
            with (
                pa.OSFile(str(path), "wb") as sink,
                pa.ipc.new_file(sink, table.schema) as writer,
            ):
                writer.write_table(table)
        with path.open("rb+") as file:
            os.fsync(file.fileno())
        if os.name == "posix":
            descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)

    def setup(self, source):
        for part, table in iter_parts(source, self.manifest):
            self.append(part, table)

    def query(self, q):
        import pyarrow as pa
        import pyarrow.compute as pc

        kind = q.get("feature", "bars")
        parts = [
            p
            for p in self.manifest["parts"]
            if p["symbol"] == q["symbol"]
            and p["kind"] == kind
            and p["end_ts"] >= q["start_ts"]
            and p["start_ts"] <= q["end_ts"]
        ]
        if q["kind"] == "latest":
            parts = list(reversed(parts))
        fields = (
            ["ts", "value"]
            if kind != "bars"
            else (["ts", "close"] if q["kind"] == "projection" else FIELDS)
        )
        rows = []
        for part in parts:
            path = self.path(part)
            if self.parquet:
                import pyarrow.parquet as pq

                filters = [("ts", ">=", q["start_ts"]), ("ts", "<=", q["end_ts"])]
                if "value" in q:
                    filters.append(("value", "=", q["value"]))
                if "min" in q:
                    filters.extend([("value", ">=", q["min"]), ("value", "<=", q["max"])])
                table = pq.read_table(path, columns=fields, filters=filters, use_threads=False)
            else:
                if str(path) not in self.maps:
                    source = pa.memory_map(str(path), "r")
                    self.maps[str(path)] = (source, pa.ipc.open_file(source).read_all())
                table = self.maps[str(path)][1].select(fields)
                mask = pc.and_(
                    pc.greater_equal(table["ts"], q["start_ts"]),
                    pc.less_equal(table["ts"], q["end_ts"]),
                )
                if "value" in q:
                    mask = pc.and_(mask, pc.equal(table["value"], q["value"]))
                if "min" in q:
                    mask = pc.and_(
                        mask,
                        pc.and_(
                            pc.greater_equal(table["value"], q["min"]),
                            pc.less_equal(table["value"], q["max"]),
                        ),
                    )
                table = table.filter(mask)
            if q["kind"] == "latest":
                table = table.slice(max(0, len(table) - q["limit"]))
            current = [tuple(row.values()) for row in table.to_pylist()]
            rows = current + rows if q["kind"] == "latest" else rows + current
            if q["kind"] == "latest" and len(rows) >= q["limit"]:
                break
        return rows[-q["limit"] :] if q["kind"] == "latest" else rows

    def close(self):
        self.maps.clear()


def connect(name, root, manifest, binary):
    if name == "fastk":
        return FastK(root, manifest, binary)
    if name in {"sqlite", "duckdb"}:
        return Sql(root, manifest, binary, duck=name == "duckdb")
    if name in {"arrow", "parquet"}:
        return Files(root, manifest, binary, parquet=name == "parquet")
    raise ValueError(name)
