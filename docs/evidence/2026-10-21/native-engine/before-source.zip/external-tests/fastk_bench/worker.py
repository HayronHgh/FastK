"""Fresh-process measurements; result validation is outside each timed query."""

import argparse
import json
import time
from pathlib import Path

from .backends import connect
from .data import FEATURES, hash_rows


def measure(config):
    manifest = json.loads(Path(config["manifest"]).read_text())
    queries = json.loads(Path(config["queries"]).read_text())
    started = time.perf_counter_ns()
    backend = connect(config["backend"], config["store"], manifest, config["binary"])
    open_ns = time.perf_counter_ns() - started
    samples = []
    # First query is separately labelled, then an untimed prewarm precedes the mix.
    first = queries[0]
    started = time.perf_counter_ns()
    result = backend.query(first)
    first_ns = time.perf_counter_ns() - started
    if hash_rows(result) != first["expected"]:
        raise AssertionError("first-touch mismatch")
    for query in queries:
        started = time.perf_counter_ns()
        result = backend.query(query)
        elapsed = time.perf_counter_ns() - started
        observed = hash_rows(result)
        if observed != query["expected"]:
            raise AssertionError(f"result mismatch: {query}")
        samples.append({"kind": query["kind"], "ns": elapsed, "result": observed})
    # Identical caller computation and data requests on every backend.
    symbols = sorted({part["symbol"] for part in manifest["parts"]})
    workload_start = time.perf_counter_ns()
    checksum = 0
    loaded = 0
    for symbol in symbols:
        parts = [
            part
            for part in manifest["parts"]
            if part["symbol"] == symbol and part["kind"] == "bars"
        ]
        bounds = {
            "symbol": symbol,
            "start_ts": min(p["start_ts"] for p in parts),
            "end_ts": max(p["end_ts"] for p in parts),
            "kind": "scan",
        }
        bars = backend.query(bounds)
        indicators = {name: dict(backend.query(dict(bounds, feature=name))) for name in FEATURES}
        for row in bars:
            ts, open, high, low, close, volume = row
            checksum += (close - open) * (1 if close >= indicators["ma20"][ts] else -1)
            # Consume every stored feature, rather than only its row count.
            checksum += sum(indicators[name][ts] for name in FEATURES)
        loaded += len(bars)
    workload_ns = time.perf_counter_ns() - workload_start
    backend.close()
    return {
        "backend": config["backend"],
        "round": config["round"],
        "open_ns": open_ns,
        "first_query_ns": first_ns,
        "samples": samples,
        "research": {"ns": workload_ns, "rows": loaded, "checksum": str(checksum)},
        "cache_state": "OS cache uncontrolled; fresh worker per round, first touch separate; connection reused except FastK subprocess per operation",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    result = measure(config)
    Path(config["output"]).write_text(json.dumps(result, indent=2) + "\n")
