//! Write ownership and scalar append semantics, kept separate from query paths.
use super::*;

impl FastKStore {
    pub(super) fn begin_mutation(&self) -> Result<Option<StoreWriteLock>> {
        self.acquire_write_ownership(true)
    }

    pub(super) fn acquire_write_ownership(&self, recover: bool) -> Result<Option<StoreWriteLock>> {
        if self.read_only {
            return Err(FastKError::InvalidInput("read-only store handle".into()));
        }
        if self.batch_lock.is_some() {
            return Ok(None);
        }
        let lock = StoreWriteLock::acquire(&self.root)?;
        if recover && recovery::has_pending_recovery(&self.root)? {
            recovery::startup_recover_locked(&self.root, recovery::RecoveryOptions::default())?;
        }
        self.clear_read_caches();
        manifest::invalidate_root(&self.root);
        Ok(Some(lock))
    }

    /// Keeps preflight, registration and all monthly commits under one writer.
    /// Each month commits independently; this is not a multi-month transaction.
    pub(crate) fn with_write_batch<T>(
        &mut self,
        action: impl FnOnce(&mut Self) -> Result<T>,
    ) -> Result<T> {
        if self.batch_lock.is_some() {
            return action(self);
        }
        self.batch_lock = self.begin_mutation()?;
        let result = action(self);
        self.batch_lock.take();
        result
    }

    /// Appends a strictly later scalar month batch without discarding prior rows.
    /// `put_scalar_chunk` retains its existing whole-month replacement semantics.
    pub fn append_scalar_chunk(
        &mut self,
        key: &ScalarSeriesKey,
        timeframe_ms: i64,
        records: &[ScalarRecord],
        block_size: usize,
    ) -> Result<()> {
        ScalarRecord::validate_strict_order(records)?;
        let month = path::month_key(records[0].ts)?;
        if path::month_key(records.last().unwrap().ts)? != month {
            return Err(FastKError::InvalidInput(
                "scalar append must stay in one UTC month".into(),
            ));
        }
        self.with_write_batch(|store| {
            let mut combined = match store.load_scalar_meta(key) {
                Ok(meta) => {
                    if meta.timeframe_ms != timeframe_ms {
                        return Err(FastKError::InvalidInput(
                            "scalar timeframe does not match existing series".into(),
                        ));
                    }
                    let mut rows = Vec::new();
                    for index in meta.chunk_indices_for_month(&month) {
                        let chunk = &meta.chunks[index];
                        if chunk.state.is_readable() {
                            rows.extend(store.get_scalar_range(
                                key,
                                chunk.start_ts,
                                chunk.end_ts,
                            )?);
                        }
                    }
                    rows
                }
                Err(FastKError::NotFound(_)) => Vec::new(),
                Err(err) => return Err(err),
            };
            if combined.last().is_some_and(|last| last.ts >= records[0].ts) {
                return Err(FastKError::InvalidInput(
                    "scalar append overlaps existing month".into(),
                ));
            }
            combined.extend_from_slice(records);
            store.put_scalar_chunk(key, timeframe_ms, &combined, block_size)
        })
    }
}
