use std::sync::{Arc, Barrier};

use fastk::{FastKStore, KlineRecord, MetricsLevel, ScalarRecord, ScalarSeriesKey};

const START: i64 = 1_704_067_200_000;

fn rows(count: usize) -> Vec<KlineRecord> {
    (0..count)
        .map(|i| KlineRecord {
            ts: START + i as i64 * 1000,
            open: i as i64,
            high: i as i64 + 1,
            low: -(i as i64),
            close: i as i64,
            volume: i64::MAX - i as i64,
        })
        .collect()
}

#[test]
fn shared_cached_and_uncached_ranges_match_across_threads() {
    let root = tempfile::tempdir().unwrap();
    let expected = Arc::new(rows(100_000));
    let key = ScalarSeriesKey {
        symbol: "A".into(),
        category: "feature".into(),
        name: "x".into(),
    };
    let scalar: Vec<_> = expected
        .iter()
        .map(|r| ScalarRecord {
            ts: r.ts,
            value: r.low,
        })
        .collect();
    let mut writer = FastKStore::open(root.path()).unwrap();
    writer
        .append_kline_range("A", "1s", &expected, 1000, 1, 1)
        .unwrap();
    writer
        .append_scalar_range(&key, &scalar, Some(1000))
        .unwrap();
    drop(writer);
    let mut store = FastKStore::open_read_only(root.path()).unwrap();
    store.set_read_threads(4).unwrap();
    store.set_metrics_level(MetricsLevel::Off);
    let store = Arc::new(store);
    let barrier = Arc::new(Barrier::new(8));
    std::thread::scope(|scope| {
        for id in 0..8 {
            let (store, expected, barrier) = (store.clone(), expected.clone(), barrier.clone());
            scope.spawn(move || {
                barrier.wait();
                for round in 0..2_000 {
                    let start = (id * 1024 + round * 7) % 20_000;
                    let end = start + 127;
                    let actual = store
                        .get_kline_range("A", "1s", expected[start].ts, expected[end - 1].ts)
                        .unwrap();
                    assert_eq!(actual, expected[start..end]);
                }
            });
        }
    });
    assert_eq!(
        store.get_kline_range("A", "1s", START, i64::MAX).unwrap(),
        *expected
    );
    assert_eq!(
        store.get_kline_latest_n("A", "1s", expected.len()).unwrap(),
        *expected
    );
    assert_eq!(
        store.get_scalar_range(&key, START, i64::MAX).unwrap(),
        scalar
    );
}

#[test]
fn rejected_inputs_leave_readable_store_and_compaction_debt_resets() {
    let root = tempfile::tempdir().unwrap();
    let expected = rows(6);
    let mut store = FastKStore::open(root.path()).unwrap();
    store
        .append_kline_range("A", "1s", &expected[..1], 1000, 1, 1)
        .unwrap();
    assert!(store
        .put_kline_chunk("A", "1s", &[expected[2], expected[1]])
        .is_err());
    assert!(store.put_kline_chunk("A", "1s", &[]).is_err());
    assert!(store.register_kline_series("A", "1s", 1000, 2, 1).is_err());
    assert!(store.register_kline_series("B", "1s", 0, 1, 1).is_err());
    for row in &expected[1..5] {
        store.put_kline_chunk("A", "1s", &[*row]).unwrap();
    }
    assert_eq!(
        store.kline_compaction_advice("A", "1s").unwrap()[0].delta_chunk_count,
        4
    );
    store.merge_kline_month("A", "1s", "2024-01").unwrap();
    let debt = store.kline_compaction_advice("A", "1s").unwrap();
    assert_eq!(
        (
            debt[0].delta_chunk_count,
            debt[0].delta_total_bytes,
            debt[0].append_count
        ),
        (0, 0, 0)
    );
    store.put_kline_chunk("A", "1s", &expected[5..]).unwrap();
    assert_eq!(
        store.kline_compaction_advice("A", "1s").unwrap()[0].delta_chunk_count,
        1
    );
    drop(store);
    assert_eq!(
        FastKStore::open_read_only(root.path())
            .unwrap()
            .get_kline_latest_n("A", "1s", 10)
            .unwrap(),
        expected
    );
}

#[test]
fn short_lookup_reads_one_sparse_window_and_bounds_capacity() {
    let root = tempfile::tempdir().unwrap();
    let expected = rows(5000);
    let mut store = FastKStore::open(root.path()).unwrap();
    store
        .append_kline_range("A", "1s", &expected, 1000, 1, 1)
        .unwrap();
    store.set_metrics_level(MetricsLevel::Detailed);
    store.get_kline_at("A", "1s", START).unwrap();
    store.reset_metrics();
    assert_eq!(
        store
            .get_kline_range("A", "1s", START + 1000, START + 1000)
            .unwrap(),
        expected[1..2]
    );
    assert_eq!(store.metrics_snapshot().bytes_read, 128 * 48);
    let out = store
        .get_kline_range("A", "1s", START, START + 2048 * 1000)
        .unwrap();
    assert_eq!(out, expected[..2049]);
    assert!(out.capacity() <= 4096);
}
