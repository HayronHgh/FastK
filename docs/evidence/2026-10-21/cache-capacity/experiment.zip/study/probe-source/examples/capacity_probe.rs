use fastk::{capacity_probe as p,scoped_scalar_series_key,FastKStore,MetricsLevel};
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::time::Instant;
#[link(name="kernel32")]
unsafe extern "system" {fn GetCurrentProcess()->*mut std::ffi::c_void;fn GetProcessHandleCount(h:*mut std::ffi::c_void,n:*mut u32)->i32;}
fn handles()->u32{let mut n=0;assert_ne!(unsafe{GetProcessHandleCount(GetCurrentProcess(),&mut n)},0);n}
enum Rows{Kline(Vec<fastk::KlineRecord>),Scalar(Vec<fastk::ScalarRecord>)}
impl Rows{fn bytes(&self)->&[u8]{match self{Self::Kline(v)=>bytemuck::cast_slice(v),Self::Scalar(v)=>bytemuck::cast_slice(v)}}}
fn read(s:&FastKStore,q:&Value)->Rows{
 let symbol=q["symbol"].as_str().unwrap();let a=q["start_ts"].as_i64().unwrap();let b=q["end_ts"].as_i64().unwrap();
 if let Some(f)=q["feature"].as_str(){let k=scoped_scalar_series_key(symbol,"1m","feature",f);let rows=s.get_scalar_range(&k,a,b).unwrap();assert_eq!(rows.len(),q["expected"]["rows"].as_u64().unwrap() as usize);Rows::Scalar(rows)}
 else {let rows=s.get_kline_range(symbol,"1m",a,b).unwrap();assert_eq!(rows.len(),q["expected"]["rows"].as_u64().unwrap() as usize);Rows::Kline(rows)}
}
fn verify(bytes:&[u8],q:&Value){let width=if q.get("feature").is_some(){2}else{6};let mut h=Sha256::new();for row in bytes.chunks_exact(width*8){let words:Vec<i64>=row.chunks_exact(8).map(|x|i64::from_le_bytes(x.try_into().unwrap())).collect();h.update(serde_json::to_vec(&words).unwrap());h.update(b"\n");}assert_eq!(format!("{:x}",h.finalize()),q["expected"]["sha256"].as_str().unwrap());}
fn query(s:&FastKStore,q:&Value,i:usize)->Value{
 s.reset_metrics();s.set_metrics_level(MetricsLevel::Detailed);p::reset(true);
 let t=Instant::now();let bytes=read(s,q);let elapsed=t.elapsed().as_nanos() as u64;
 let probe=p::snapshot();p::reset(false);let metrics=s.metrics_snapshot();verify(bytes.bytes(),q);
 assert_eq!(probe[2],metrics.chunk_file_cache_misses);assert_eq!(probe[0],metrics.chunk_file_cache_hits+metrics.chunk_file_cache_misses);
 json!({"index":i,"case":q["case"],"read_ns":elapsed,"probe":probe,"metrics":metrics})
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let c:Value=serde_json::from_slice(&std::fs::read(&args[1]).unwrap()).unwrap();
 std::env::set_var("FASTK_PROBE_CAP",c["capacity"].as_u64().unwrap().to_string());
 let qs:Vec<Value>=serde_json::from_slice(&std::fs::read(c["queries"].as_str().unwrap()).unwrap()).unwrap();
 let order:Vec<usize>=serde_json::from_value(c["order"].clone()).unwrap();let root=c["store"].as_str().unwrap();let mode=c["mode"].as_str().unwrap();let mut samples=vec![];let mut lifetime=vec![];let baseline=handles();
 if mode.starts_with("hot"){
  let t=Instant::now();let s=FastKStore::open_read_only(root).unwrap();let open=t.elapsed().as_nanos() as u64;s.set_metrics_level(MetricsLevel::Off);
  for(i,q)in qs.iter().enumerate(){for _ in 0..32{let bytes=read(&s,q);assert_eq!(bytes.bytes().len(),q["expected"]["rows"].as_u64().unwrap() as usize*6*8);}if mode=="hot-local"{samples.push(query(&s,q,i));s.set_metrics_level(MetricsLevel::Off);}}
  let warm_handles=handles();if mode=="hot-replay"{for &i in &order{samples.push(query(&s,&qs[i],i));}}
  let before_close=handles();let t=Instant::now();drop(s);let close=t.elapsed().as_nanos() as u64;
  lifetime.push(json!({"open_ns":open,"close_ns":close,"warm_handles":warm_handles,"before_close_handles":before_close,"after_close_handles":handles()}));
 }else{
  for repetition in 0..c["repetitions"].as_u64().unwrap(){let cycle_order:Vec<usize>=serde_json::from_value(c["orders"][repetition as usize].clone()).unwrap();for &i in &cycle_order{
   p::reset(false);let t=Instant::now();let s=FastKStore::open_read_only(root).unwrap();let open=t.elapsed().as_nanos() as u64;
   let mut sample=query(&s,&qs[i],i);let before_close=handles();let t=Instant::now();drop(s);let close=t.elapsed().as_nanos() as u64;
   sample["open_ns"]=json!(open);sample["close_ns"]=json!(close);sample["before_close_handles"]=json!(before_close);sample["after_close_handles"]=json!(handles());samples.push(sample);
  }}
 }
 assert_eq!(handles(),baseline);
 std::fs::write(c["output"].as_str().unwrap(),serde_json::to_vec_pretty(&json!({"capacity":c["capacity"],"mode":mode,"samples":samples,"lifetime":lifetime,"baseline_handles":baseline,"after_close_handles":handles(),"all_results_verified":true,"profile_only":true,"probe_fields":["cache_calls","cache_ns","open_calls","open_ns","io_calls","io_ns","eviction_drop_calls","eviction_drop_ns","io_bytes"],"limits":["Separate instrumented Rust attribution, not primary NumPy timing","read_ns includes probe overhead; not a native latency ranking","Cache path contains open and eviction-drop spans; IO spans contain clock overhead"]})).unwrap()).unwrap();
}
