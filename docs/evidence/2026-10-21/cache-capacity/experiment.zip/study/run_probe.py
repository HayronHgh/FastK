import hashlib,json,os,random,subprocess
from pathlib import Path
B=Path(__file__).resolve().parent;ROOT=B.parents[1];O=B/'attribution';O.mkdir(exist_ok=False)
exe=B/'cargo-probe/release/examples/capacity_probe.exe'
jobs=[]
for r in range(3):
    batch=[{'capacity':cap,'mode':mode,'round':r} for cap in [64,128,256] for mode in ['hot-local','hot-replay','cycle-short','cycle-bulk']]
    random.Random(20261024+r).shuffle(batch);jobs+=batch
for i,j in enumerate(jobs):
    stem=f"{i:02}-{j['capacity']}-{j['mode']}-r{j['round']}";out=O/(stem+'.json')
    queries=B/('bulk.json' if j['mode']=='cycle-bulk' else 'short.json');qs=json.loads(queries.read_text());order=list(range(len(qs)));random.Random(20261021).shuffle(order)
    reps=5 if j['mode']=='cycle-bulk' else 1
    orders=[]
    for repetition in range(reps):
        cycle_order=list(range(len(qs)));random.Random(20261021+repetition).shuffle(cycle_order);orders.append(cycle_order)
    c={**j,'store':str(ROOT/'target/external-standard-evidence/fastk'),'queries':str(queries),'order':order,'orders':orders,'repetitions':reps,'output':str(out)}
    config=O/(stem+'-config.json');config.write_text(json.dumps(c)+'\n')
    with (O/(stem+'.log')).open('wb') as log:subprocess.run([str(exe),str(config)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    result=json.loads(out.read_text());assert result['all_results_verified'];j['output']=out.name
    print('attributed',stem,flush=True)
(O/'plan.json').write_text(json.dumps({'jobs':jobs,'rounds':3,'probe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'all_results_verified':True},indent=2)+'\n')
