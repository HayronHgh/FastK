import hashlib,importlib.metadata,json,os,platform,random,statistics,sys
from pathlib import Path
import numpy as np
from fastk_bench.process import run

B=Path(__file__).resolve().parent;ROOT=B.parents[1]
O=B/'timing';O.mkdir(exist_ok=False)
modules=json.loads((B/'modules-isolated.json').read_text());jobs=[]
for r in range(5):
    batch=[{'backend':'fastk','capacity':cap,'workload':w,'round':r} for cap in [64,128,256] for w in ['hot-local','hot-replay','cycle-short','cycle-bulk']]
    batch += [{'backend':'arrow','capacity':256,'workload':w,'round':r} for w in ['hot-local','hot-replay']]
    random.Random(20261022+r).shuffle(batch);jobs+=batch
(O/'plan.json').write_text(json.dumps({'rounds':5,'jobs':jobs,'short_sha256':hashlib.sha256((B/'short.json').read_bytes()).hexdigest(),'bulk_sha256':hashlib.sha256((B/'bulk.json').read_bytes()).hexdigest(),'bulk_repetitions':5,'warmup_per_query':32,'order_seed':20261021,'timing_probes':False},indent=2)+'\n')
outputs=[]
for i,j in enumerate(jobs):
    stem=f"{i:02}-{j['backend']}-{j['capacity']}-{j['workload']}-r{j['round']}";out=O/(stem+'.json')
    module=modules[str(j['capacity'])] if j['backend']=='fastk' else None
    os.environ['PYTHONPATH']=os.pathsep.join(([module['root']] if module else [])+[str(B),str(ROOT/'external-tests')])
    c={'backend':j['backend'],'capacity':j['capacity'],'mode':j['workload'],'store':str(ROOT/'target/external-standard-evidence'/j['backend']),'manifest':str(B/'manifest.json'),'queries':str(B/('bulk.json' if j['workload']=='cycle-bulk' else 'short.json')),'repetitions':5 if j['workload']=='cycle-bulk' else 1,'native_sha256':module['sha256'] if module else None,'output':str(out)}
    config=out.with_name(stem+'-config.json');config.write_text(json.dumps(c)+'\n')
    result=run('worker',config,out,600);assert result['all_results_verified'];j['output']=out.name;outputs.append((j,result))
    print('verified',stem,flush=True)
rows=[]
for key in sorted({(j['backend'],j['capacity'],j['workload'],s['case']) for j,r in outputs for s in r['samples']}):
    b,cap,w,case=key;matched=[r for j,r in outputs if (j['backend'],j['capacity'],j['workload'])==key[:3]]
    phases={}
    for f in (['read_ns'] if w.startswith('hot') else ['open_ns','read_ns','close_ns','total_ns']):
        xs=[[s[f] for s in r['samples'] if s['case']==case] for r in matched]
        phases[f]={'process_medians':[statistics.median(x) for x in xs],'median_ns':statistics.median(statistics.median(x) for x in xs),'p95_ns':statistics.median(float(np.percentile(x,95)) for x in xs),'p99_ns':statistics.median(float(np.percentile(x,99)) for x in xs)}
    rows.append({'backend':b,'capacity':cap,'workload':w,'case':case,'phases':phases,'peak_rss':[r['memory']['peak_rss_bytes'] for r in matched],'peak_private':[r['memory']['peak_private_bytes'] for r in matched],'handle_deltas':[r['handle_delta_after_close'] for r in matched],'resources':[r['resources'] for r in matched],'lifetime':[r['lifetime'] for r in matched]})
summary={'processes':len(outputs),'timed_outputs':sum(len(r['samples']) for _,r in outputs),'all_results_verified':True,'results':rows,'jobs':jobs,'modules':modules,'environment':{'python':sys.version,'platform':platform.platform(),'packages':{n:importlib.metadata.version(n) for n in ['numpy','pyarrow','psutil']}}}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('COMPLETE',summary['processes'],summary['timed_outputs'],flush=True)
