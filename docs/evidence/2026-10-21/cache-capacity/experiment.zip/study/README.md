# File handle cache capacity experiment

Goal: hold the production default and public API unchanged; compare only 64,
128 and 256 retained handles with the frozen 1,430 short queries and four bulk
cases from the previous lazy-read experiment.

Primary timings use three isolated source copies. Each differs only in the
private DEFAULT_FILE_CACHE_CAPACITY constant. Source manifests and actual DLL
hashes pin the binaries. Build output directories MUST be independent: an
initial shared-target attempt reused the same DLL; those artifacts are invalid
and are not used by run.py. No production native package is installed/changed.

Primary: five independent process rounds per capacity/workload, randomized
setting order. hot-local warms each query 32 times immediately before timing;
hot-replay warms the same complete set then replays the frozen randomized
order. Both time only query-to-NumPy delivery and separately time Reader open
and close/destruction. cycle-short creates and closes a reader for each query;
cycle-bulk does the same for all four cases, five repetitions each. Arrow256
hot-local/replay is rerun as a contemporaneous reference, not a new format race.

All outputs use the same readonly packed structured int64 NumPy contract.
First unique output checks the complete canonical row hash; all repetitions
check complete packed bytes. Cycle results and retained hot witnesses are
checked after Reader close. No retry or replay on failure. Process memory is
sampled by the existing external monitor every 5 ms; occasional resource
snapshots and handle counts occur outside timers. Memory includes imports,
warmup, validation and the retained last hot result, not just incremental IO.
All imports are outside open timers; OS cache is uncontrolled. A fresh Reader
does not mean cold disk. One internal thread, resident Python process.

Attribution: separate instrumented Rust source and executable; no probes enter
the primary native DLLs. Same warmups, query order, data and capacities. Three
process rounds per setting. Existing Detailed metrics count header/file hits
and misses. Additional probes time cache-path calls, File::open, positional IO
and eviction Arc<File> drops. Cache-path time contains open and eviction drops;
these spans must not be added twice. Whole-store drop is timed separately.
IO includes header/index reads when cold, and clock/counter overhead. Explicit
resource handle count returns to its starting value after all reads close.
Every timed diagnostic output is canonically checked. Attribution timing is
not substituted into the NumPy timing ranking; Rust bypasses Python bootstrap
and conversion, and detailed probes perturb short operations.

Reproduce from repository root with CPython3.12, the existing benchmark deps,
Maturin and the installed Windows GNU Rust toolchain. Prepare standard stores
first as in external-tests/read_lifecycle/README.md. Set PYTHONUTF8=1,
RUSTUP_TOOLCHAIN=stable-x86_64-pc-windows-gnu and TEMP/TMP to a writable workspace
directory. prepare.py refuses to overwrite source snapshots; run.py and
run_probe.py refuse existing result directories. Build all artifacts and run
contract checks BEFORE any timings. Never compile or copy large evidence while
timing workers run. No arbitrary environment switch is added to production;
FASTK_PROBE_CAP exists only in the diagnostic source copy.

1. python target/cache-capacity-study/prepare.py
2. python target/cache-capacity-study/build.py
3. python target/cache-capacity-study/prepare_probe.py
4. cargo build --manifest-path target/cache-capacity-study/probe-source/Cargo.toml --example capacity_probe --release --locked --offline
   (set CARGO_TARGET_DIR to target/cache-capacity-study/cargo-probe)
5. PYTHONPATH includes target/cache-capacity-study and external-tests;
   python target/cache-capacity-study/run.py
6. python target/cache-capacity-study/run_probe.py

An original-source toolchain lookup and a missing snapshot README also caused
two early build setup failures. Logs are retained. They are not measurement
results. The package README is present in the final source manifest.

To replay an archived run, preserve the original study directory and use a fresh
root/target/<new-study-name> directory containing the runner .py/.rs/.md files.
Restore the archived source-64 files at that separate root (matching the source
manifest), place the bundled fastk_bench and test_native.py under external-tests,
and regenerate standard stores/frozen input paths first. Do not invoke prepare.py
inside an archive that already contains source-*; it intentionally refuses.
Existing absolute paths in original config/results are provenance, not portable
replay config; run.py regenerates them for the new root. Build steps require
previously cached locked crates for offline mode.
