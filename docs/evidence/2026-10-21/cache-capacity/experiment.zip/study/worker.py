"""Capacity-only native variants; no instrumentation inside timed calls."""
import hashlib,importlib,inspect,json,os,random,sys,textwrap,time
from pathlib import Path
import psutil
from fastk_bench import backends
from fastk_bench.batches import columns_for,validate
from fastk_bench.matrix_worker import checked
from fastk_bench.process import announce

def measure(c):
    announce(c)
    if c['backend']=='fastk':
        mod=importlib.import_module('fastk_native._native')
        assert hashlib.sha256(Path(mod.__file__).read_bytes()).hexdigest()==c['native_sha256']
    else:
        importlib.import_module('pyarrow.dataset')
        src=textwrap.dedent(inspect.getsource(backends.Files.query_ipc))
        assert src.count('if len(self.ipc_batches) > 64:')==1
        ns=vars(backends).copy();exec(compile(src.replace('if len(self.ipc_batches) > 64:','if len(self.ipc_batches) > 256:'),'<arrow256>', 'exec'),ns)
        backends.Files.query_ipc=ns['query_ipc']
    manifest=json.loads(Path(c['manifest']).read_text());qs=json.loads(Path(c['queries']).read_text())
    hashes={};samples=[];life=[];process=psutil.Process();baseline=process.num_handles()
    def snap(stage):
        m=process.memory_info();life.append({'stage':stage,'handles':process.num_handles(),'rss':m.rss,'private':m.private})
    def verify(a,i):
        validate(a,columns_for(qs[i]));h=hashlib.sha256(a).digest()
        if i not in hashes:checked(a,qs[i]);hashes[i]=h
        assert h==hashes[i] and len(a)==qs[i]['expected']['rows']
    def connect():return backends.connect(c['backend'],c['store'],manifest,threads=1)
    snap('baseline')
    if c['mode'].startswith('hot'):
        t=time.perf_counter_ns();b=connect();open_ns=time.perf_counter_ns()-t;snap('opened')
        witness=None;witness_i=None
        try:
            for i,q in enumerate(qs):
                for _ in range(32):
                    a=b.query(q);verify(a,i);del a
                if c['mode']=='hot-local':
                    t=time.perf_counter_ns();a=b.query(q);ns=time.perf_counter_ns()-t
                    verify(a,i);samples.append({'index':i,'case':q['case'],'read_ns':ns});witness=a;witness_i=i;del a
            snap('after_warmup')
            if c['mode']=='hot-replay':
                order=list(range(len(qs)));random.Random(20261021).shuffle(order)
                for i in order:
                    t=time.perf_counter_ns();a=b.query(qs[i]);ns=time.perf_counter_ns()-t
                    verify(a,i);samples.append({'index':i,'case':qs[i]['case'],'read_ns':ns});witness=a;witness_i=i;del a
            snap('after_timed_queries')
        finally:
            t=time.perf_counter_ns();b.close();del b;close_ns=time.perf_counter_ns()-t
        snap('after_close');verify(witness,witness_i);del witness
        lifetime={'open_ns':open_ns,'close_ns':close_ns}
    else:
        for r in range(c['repetitions']):
            order=list(range(len(qs)));random.Random(20261021+r).shuffle(order)
            for i in order:
                t=time.perf_counter_ns();b=connect();opened=time.perf_counter_ns()
                try:a=b.query(qs[i]);read=time.perf_counter_ns()
                finally:b.close();del b
                closed=time.perf_counter_ns();verify(a,i)
                samples.append({'index':i,'case':qs[i]['case'],'round':r,'open_ns':opened-t,'read_ns':read-opened,'close_ns':closed-read,'total_ns':closed-t})
                assert samples[-1]['total_ns']==sum(samples[-1][x] for x in ['open_ns','read_ns','close_ns'])
                del a
        snap('after_close');lifetime=None
    return {'python_pid':os.getpid(),'backend':c['backend'],'capacity':c['capacity'],'mode':c['mode'],'samples':samples,'lifetime':lifetime,'resources':life,'handle_delta_after_close':life[-1]['handles']-baseline,'all_results_verified':True,'native_sha256':c.get('native_sha256'),'limits':['OS cache uncontrolled; imports excluded; one thread; same readonly packed NumPy outputs','Hot lifetime timings include adapter destruction; validation outside read/close timers','Sampled memory includes warmup and validation; phase snapshots outside timers']}

if __name__=='__main__':
    c=json.loads(Path(sys.argv[1]).read_text());Path(c['output']).write_text(json.dumps(measure(c),indent=2)+'\n')
