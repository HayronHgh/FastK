from pathlib import Path
import hashlib,json,shutil

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'README.md',ROOT/'LICENSE',*sorted((ROOT/'src').rglob('*.rs')),*sorted((ROOT/'clients/python-native').rglob('*.rs')),*sorted((ROOT/'clients/python-native/python').rglob('*.py')),ROOT/'clients/python-native/Cargo.toml',ROOT/'clients/python-native/pyproject.toml']
source={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
assert 'DEFAULT_FILE_CACHE_CAPACITY: usize = 64;' in (ROOT/'src/store_core/chunk/cache.rs').read_text()
for cap in [64,128,256]:
    dest=BASE/f'source-{cap}';dest.mkdir(exist_ok=False)
    for p in paths:
        target=dest/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    p=dest/'src/store_core/chunk/cache.rs'
    t=p.read_text();assert t.count('DEFAULT_FILE_CACHE_CAPACITY: usize = 64;')==1
    p.write_text(t.replace('DEFAULT_FILE_CACHE_CAPACITY: usize = 64;',f'DEFAULT_FILE_CACHE_CAPACITY: usize = {cap};'),newline='\n')
    for key,digest in source.items():
        if key!='src/store_core/chunk/cache.rs':assert sha(dest/key)==digest,key
    assert p.read_text().replace(f'DEFAULT_FILE_CACHE_CAPACITY: usize = {cap};','DEFAULT_FILE_CACHE_CAPACITY: usize = 64;')==(ROOT/'src/store_core/chunk/cache.rs').read_text()
(BASE/'source-baseline.json').write_text(json.dumps(source,indent=2)+'\n')
for src,name in [('target/v02-final-linux-matrix/short.json','short.json'),('target/v02-final-linux-matrix/bulk.json','bulk.json'),('target/external-standard-final/input/manifest.json','manifest.json')]:shutil.copy2(ROOT/src,BASE/name)
print('Prepared three source copies; only capacity differs; original source unchanged')
