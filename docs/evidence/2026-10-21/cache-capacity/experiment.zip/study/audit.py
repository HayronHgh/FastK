from pathlib import Path
import hashlib,json,statistics,zipfile
import numpy as np
B=Path(__file__).resolve().parent;ROOT=B.parents[1]
S=json.loads((B/'timing/summary.json').read_text());groups={};count=0
for j in S['jobs']:
    r=json.loads((B/'timing'/j['output']).read_text());assert r['all_results_verified']
    assert len(r['samples'])==(20 if j['workload']=='cycle-bulk' else 1430)
    if j['backend']=='fastk':
        assert r['handle_delta_after_close']==0
        assert r['native_sha256']==S['modules'][str(j['capacity'])]['sha256']
        if j['workload'].startswith('hot'):
            snaps=r['resources'];active=next(x for x in snaps if x['stage']=='after_timed_queries')['handles']-snaps[0]['handles']
            assert active==min(j['capacity'],240)+1
    for sample in r['samples']:
        if 'total_ns' in sample:assert sample['total_ns']==sum(sample[k] for k in ['open_ns','read_ns','close_ns'])
    for case in {s['case'] for s in r['samples']}:
        groups.setdefault((j['backend'],j['capacity'],j['workload'],case),[]).append([s for s in r['samples'] if s['case']==case])
    count+=len(r['samples'])
assert count==78950
for row in S['results']:
    xs=groups[(row['backend'],row['capacity'],row['workload'],row['case'])];assert len(xs)==5
    for field,stats in row['phases'].items():
        assert stats['process_medians']==[statistics.median(s[field] for s in proc) for proc in xs]
        assert stats['median_ns']==statistics.median(stats['process_medians'])
        for p,key in [(95,'p95_ns'),(99,'p99_ns')]:assert stats[key]==statistics.median(float(np.percentile([s[field] for s in proc],p)) for proc in xs)
plan=json.loads((B/'attribution/plan.json').read_text());diag_count=0
for j in plan['jobs']:
    r=json.loads((B/'attribution'/j['output']).read_text());assert r['baseline_handles']==r['after_close_handles'];diag_count+=len(r['samples'])
    if j['mode']=='hot-replay':
        misses=sum(s['metrics']['chunk_file_cache_misses'] for s in r['samples']);assert misses=={64:1056,128:671,256:0}[j['capacity']]
        assert all(s['metrics']['chunk_header_cache_misses']==0 for s in r['samples'])
    if j['mode'].startswith('cycle'):
        assert all(s['probe'][6]==0 for s in r['samples'])
assert diag_count==38790
for cap in [64,128,256]:
    log=(B/f'contract-{cap}.log').read_text();assert 'Ran 9 tests' in log and '\nOK\n' in log
assert hashlib.sha256((B/'short.json').read_bytes()).digest()==hashlib.sha256((ROOT/'target/v02-final-linux-matrix/short.json').read_bytes()).digest()
assert hashlib.sha256((B/'bulk.json').read_bytes()).digest()==hashlib.sha256((ROOT/'target/v02-final-linux-matrix/bulk.json').read_bytes()).digest()
E=ROOT/'docs/evidence/2026-10-21/cache-capacity';hashes=json.loads((E/'SHA256SUMS.json').read_text())
assert all(hashlib.sha256((E/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
with zipfile.ZipFile(E/'experiment.zip') as z:
    assert z.testzip() is None
    for p in B.iterdir():
        if p.is_file() and p.suffix in ['.py','.rs','.md','.json','.log'] and p.name!='audit.py':
            assert z.read('study/'+p.name)==p.read_bytes(),p.name
result={'primary_processes':70,'primary_outputs':count,'profile_processes':36,'profile_outputs':diag_count,'all_summaries_recomputed':True,'effective_capacity_verified_by_handles':True,'all_fastk_handles_return_to_baseline':True,'frozen_query_hashes_match':True,'native_tests':27,'zip_crc_and_hashes_pass':True}
(B/'completion-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
