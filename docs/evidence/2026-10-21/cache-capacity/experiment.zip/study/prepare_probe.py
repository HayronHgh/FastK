from pathlib import Path
import shutil
B=Path(__file__).resolve().parent
P=B/'probe-source';shutil.copytree(B/'source-64',P)
lib=P/'src/lib.rs';lib.write_text(lib.read_text()+'\npub mod capacity_probe;\n',newline='\n')
shutil.copy2(B/'capacity_probe.rs',P/'src/capacity_probe.rs')
p=P/'src/store_core/chunk/cache.rs';t=p.read_text()
needle='Self::new(DEFAULT_FILE_CACHE_CAPACITY)'
assert t.count(needle)==1;t=t.replace(needle,'Self::new(std::env::var("FASTK_PROBE_CAP").unwrap().parse().unwrap())')
needle='pub fn open(&self, key: ChunkCacheKey, path: &Path) -> Result<ChunkFile> {'
assert t.count(needle)==1;t=t.replace(needle,needle+'\n        let _probe_cache = crate::capacity_probe::Span::new(0);')
needle='let opened = Arc::new(File::open(path)?);';assert t.count(needle)==1
t=t.replace(needle,'let opened = { let _probe_open = crate::capacity_probe::Span::new(2); Arc::new(File::open(path)?) };')
needle='drop(evicted);';assert t.count(needle)==1
t=t.replace(needle,'if evicted.is_some() { let _probe_close = crate::capacity_probe::Span::new(6); drop(evicted); }')
p.write_text(t,newline='\n')
p=P/'src/store_core/chunk/file.rs';t=p.read_text();needle='fn read_uninit(&mut self, bytes: &mut [MaybeUninit<u8>]) -> io::Result<usize> {'
assert t.count(needle)==1;t=t.replace(needle,needle+'\n        let _probe_io = crate::capacity_probe::Span::new(4);')
needle='self.offset = self\n            .offset\n            .checked_add(count as u64)';assert t.count(needle)==1
t=t.replace(needle,'crate::capacity_probe::bytes(count);\n        '+needle)
p.write_text(t,newline='\n')
(P/'examples').mkdir(exist_ok=True);shutil.copy2(B/'probe.rs',P/'examples/capacity_probe.rs')
print('Prepared separate attribution source; native timing modules remain uninstrumented')
