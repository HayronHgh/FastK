use std::sync::atomic::{AtomicBool,AtomicU64,Ordering};
use std::time::Instant;
static ON:AtomicBool=AtomicBool::new(false);
static VALUES:[AtomicU64;9]=[const {AtomicU64::new(0)};9];
pub fn reset(on:bool){ON.store(false,Ordering::Relaxed);for v in &VALUES{v.store(0,Ordering::Relaxed);}ON.store(on,Ordering::Relaxed);}
pub fn snapshot()->[u64;9]{std::array::from_fn(|i|VALUES[i].load(Ordering::Relaxed))}
pub fn bytes(n:usize){if ON.load(Ordering::Relaxed){VALUES[8].fetch_add(n as u64,Ordering::Relaxed);}}
pub struct Span{index:usize,start:Option<Instant>}
impl Span{pub fn new(index:usize)->Self{Self{index,start:ON.load(Ordering::Relaxed).then(Instant::now)}}}
impl Drop for Span{fn drop(&mut self){if let Some(start)=self.start{let ns=start.elapsed().as_nanos() as u64;VALUES[self.index].fetch_add(1,Ordering::Relaxed);VALUES[self.index+1].fetch_add(ns,Ordering::Relaxed);}}}
