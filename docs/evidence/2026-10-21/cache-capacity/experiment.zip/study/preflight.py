from pathlib import Path
import hashlib,json,os,subprocess,sys
B=Path(__file__).resolve().parent;ROOT=B.parents[1]
mods=json.loads((B/'modules-isolated.json').read_text());assert len(mods)==3 and len({m['sha256'] for m in mods.values()})==3
for cap in [64,128,256]:
    env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join([mods[str(cap)]['root'],str(ROOT/'external-tests')]);env['TEMP']=str(ROOT/'target/lifecycle-temp');env['TMP']=env['TEMP']
    with (B/f'contract-{cap}.log').open('wb') as log:subprocess.run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'external-tests'),'-p','test_native.py','-v'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    print('native contract',cap,'PASS',flush=True)
baseline=json.loads((B/'source-baseline.json').read_text())
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in baseline.items())
print('Production source/API hash preconditions unchanged',len(baseline),flush=True)
