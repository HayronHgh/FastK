from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

B=Path(__file__).resolve().parent
ROOT=B.parents[1]
env=os.environ.copy();env['TEMP']=str(ROOT/'target/lifecycle-temp');env['TMP']=env['TEMP']
env['RUSTUP_TOOLCHAIN']='stable-x86_64-pc-windows-gnu'
modules={}
for cap in [64,128,256]:
    env['CARGO_TARGET_DIR']=str(B/f'cargo-native-isolated-{cap}')
    source=B/f'source-{cap}';wheels=B/f'wheels-isolated-{cap}'
    command=[sys.executable,'-m','maturin','build','--manifest-path',str(source/'clients/python-native/Cargo.toml'),'--profile','native','--locked','--offline','--interpreter',sys.executable,'--out',str(wheels)]
    started=time.time()
    with (B/f'build-isolated-{cap}.log').open('wb') as log:subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    wheel,=wheels.glob('*.whl');dest=B/f'module-isolated-{cap}'
    with zipfile.ZipFile(wheel) as z:
        assert all((dest/n).resolve().is_relative_to(dest.resolve()) for n in z.namelist());z.extractall(dest)
    dll,=(dest/'fastk_native').glob('*.pyd')
    modules[str(cap)]={'root':str(dest),'sha256':hashlib.sha256(dll.read_bytes()).hexdigest(),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'build_seconds':time.time()-started}
    (B/'modules-isolated.json').write_text(json.dumps(modules,indent=2)+'\n')
    print('built',cap,flush=True)
assert len({m['sha256'] for m in modules.values()})==3
